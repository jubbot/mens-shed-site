export const WOOD_TOOLS = [
  'Bandsaw','Table saw','Planer','Jointer','Drill press','Router','Lathe','Sander','Mitre saw',
];

export const METAL_TOOLS = [
  'Angle grinder','Metal lathe','MIG welder','TIG welder','Arc welder','Bench grinder','Cut-off saw',
];
